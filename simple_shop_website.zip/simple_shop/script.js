let products = JSON.parse(localStorage.getItem("products")) || [
  {
    id: 1,
    name: "Classic Shirt",
    price: 350,
    stock: 12,
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 2,
    name: "Canvas Bag",
    price: 250,
    stock: 8,
    image: "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 3,
    name: "Coffee Tumbler",
    price: 499,
    stock: 5,
    image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=800&q=80"
  }
];

let cart = JSON.parse(localStorage.getItem("cart")) || [];
let orders = JSON.parse(localStorage.getItem("orders")) || [];

function saveData() {
  localStorage.setItem("products", JSON.stringify(products));
  localStorage.setItem("cart", JSON.stringify(cart));
  localStorage.setItem("orders", JSON.stringify(orders));
}

function showProducts() {
  let productList = document.getElementById("productList");
  productList.innerHTML = "";

  products.forEach(function(product) {
    let card = document.createElement("div");
    card.className = "product-card";

    card.innerHTML = `
      <img src="${product.image}" alt="${product.name}">
      <div class="product-info">
        <h3>${product.name}</h3>
        <p class="price">₱${product.price}</p>
        <p class="stock ${product.stock === 0 ? "out-stock" : ""}">
          Stock: ${product.stock}
        </p>
        <button onclick="addToCart(${product.id})" ${product.stock === 0 ? "disabled" : ""}>
          ${product.stock === 0 ? "Out of Stock" : "Add to Cart"}
        </button>
        <button class="small-btn danger-btn" onclick="deleteProduct(${product.id})">Delete</button>
      </div>
    `;

    productList.appendChild(card);
  });
}

function addToCart(productId) {
  let product = products.find(function(item) {
    return item.id === productId;
  });

  if (!product || product.stock <= 0) {
    alert("This item is out of stock.");
    return;
  }

  let cartItem = cart.find(function(item) {
    return item.id === productId;
  });

  if (cartItem) {
    if (cartItem.quantity < product.stock) {
      cartItem.quantity++;
    } else {
      alert("Not enough stock available.");
    }
  } else {
    cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      quantity: 1
    });
  }

  saveData();
  showCart();
}

function showCart() {
  let cartList = document.getElementById("cartList");
  let cartTotal = document.getElementById("cartTotal");
  cartList.innerHTML = "";

  let total = 0;

  if (cart.length === 0) {
    cartList.innerHTML = "<p>Your cart is empty.</p>";
  }

  cart.forEach(function(item) {
    let itemTotal = item.price * item.quantity;
    total += itemTotal;

    let div = document.createElement("div");
    div.className = "cart-item";
    div.innerHTML = `
      <strong>${item.name}</strong><br>
      Quantity: ${item.quantity}<br>
      Price: ₱${item.price}<br>
      Subtotal: ₱${itemTotal}<br>
      <button class="small-btn danger-btn" onclick="removeFromCart(${item.id})">Remove</button>
    `;
    cartList.appendChild(div);
  });

  cartTotal.textContent = "Total: ₱" + total;
}

function removeFromCart(productId) {
  cart = cart.filter(function(item) {
    return item.id !== productId;
  });

  saveData();
  showCart();
}

document.getElementById("orderForm").addEventListener("submit", function(event) {
  event.preventDefault();

  if (cart.length === 0) {
    alert("Cart is empty.");
    return;
  }

  for (let i = 0; i < cart.length; i++) {
    let product = products.find(function(item) {
      return item.id === cart[i].id;
    });

    if (!product || cart[i].quantity > product.stock) {
      alert("Some products do not have enough stock.");
      return;
    }
  }

  cart.forEach(function(item) {
    let product = products.find(function(product) {
      return product.id === item.id;
    });
    product.stock -= item.quantity;
  });

  let order = {
    id: Date.now(),
    date: new Date().toLocaleString(),
    name: document.getElementById("customerName").value,
    email: document.getElementById("customerEmail").value,
    phone: document.getElementById("customerPhone").value,
    address: document.getElementById("customerAddress").value,
    items: cart,
    total: cart.reduce(function(sum, item) {
      return sum + item.price * item.quantity;
    }, 0)
  };

  orders.push(order);
  cart = [];
  document.getElementById("orderForm").reset();

  saveData();
  showProducts();
  showCart();
  showOrders();

  alert("Order submitted successfully!");
});

document.getElementById("productForm").addEventListener("submit", function(event) {
  event.preventDefault();

  let product = {
    id: Date.now(),
    name: document.getElementById("productName").value,
    price: Number(document.getElementById("productPrice").value),
    stock: Number(document.getElementById("productStock").value),
    image: document.getElementById("productImage").value
  };

  products.push(product);
  document.getElementById("productForm").reset();

  saveData();
  showProducts();
});

function showOrders() {
  let orderList = document.getElementById("orderList");
  orderList.innerHTML = "";

  if (orders.length === 0) {
    orderList.innerHTML = "<p>No orders yet.</p>";
    return;
  }

  orders.slice().reverse().forEach(function(order) {
    let div = document.createElement("div");
    div.className = "order-card";

    let itemText = order.items.map(function(item) {
      return `${item.name} x ${item.quantity}`;
    }).join(", ");

    div.innerHTML = `
      <h3>Order #${order.id}</h3>
      <p><strong>Date:</strong> ${order.date}</p>
      <p><strong>Name:</strong> ${order.name}</p>
      <p><strong>Email:</strong> ${order.email}</p>
      <p><strong>Phone:</strong> ${order.phone}</p>
      <p><strong>Address:</strong> ${order.address}</p>
      <p><strong>Items:</strong> ${itemText}</p>
      <p><strong>Total:</strong> ₱${order.total}</p>
    `;

    orderList.appendChild(div);
  });
}

function deleteProduct(productId) {
  products = products.filter(function(product) {
    return product.id !== productId;
  });

  cart = cart.filter(function(item) {
    return item.id !== productId;
  });

  saveData();
  showProducts();
  showCart();
}

function clearOrders() {
  orders = [];
  saveData();
  showOrders();
}

function resetProducts() {
  localStorage.clear();
  location.reload();
}

showProducts();
showCart();
showOrders();
